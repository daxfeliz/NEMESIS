print('NEMESIS')
